package com;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpSession;

public class AlterDao {
	public boolean alter(String email, String password){
		try{
		     Altergs evo=new Altergs();
		     evo.setEmail(email);
		     evo.setPassword(password);
		     
		     Class.forName("oracle.jdbc.driver.OracleDriver");
		     System.out.println("Driver loaded successfully..");
		     Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system" ,"system");
		     System.out.println("Connection established successfully...");
		     String sql = "update account set password=? where email=?";
		     System.out.println("st executed");
		     PreparedStatement st = con.prepareStatement(sql);
		     System.out.println("email="+evo.getEmail());
		     st.setString(1,evo.getPassword());
		     System.out.println("st");
		     System.out.println("password="+evo.getPassword());
		     st.setString(2,evo.getEmail());
		     System.out.println("st");
		     int rs = st.executeUpdate();
		     System.out.println(rs);
		     if(rs>0){
		  	   con.commit();
		  	   return true;
		     }
		}
				catch(Exception e){
					System.out.println(e);
				}
				
return false;
}
}