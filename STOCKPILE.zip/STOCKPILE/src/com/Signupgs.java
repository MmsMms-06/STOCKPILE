package com;



public class Signupgs {
	 private String username;
	    private String  email;
	    private String password;
	    private String gender;
	    private String dateofbirth;
	    private String countrycode;
	    private Long  mobilenumber;
	    private String security;
		public String getSecurity() {
			return security;
		}
		public void setSecurity(String security) {
			this.security = security;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getDateofbirth() {
			return dateofbirth;
		}
		public void setDateofbirth(String dateofbirth2) {
			this.dateofbirth = dateofbirth;
		}
		public String getCountrycode() {
			return countrycode;
		}
		public void setCountrycode(String countrycode) {
			this.countrycode = countrycode;
		}
		public Long getMobilenumber() {
			return mobilenumber;
		}
		public void setMobilenumber(Long mobilenumber) {
			this.mobilenumber = mobilenumber;
		}
	    
	    
}