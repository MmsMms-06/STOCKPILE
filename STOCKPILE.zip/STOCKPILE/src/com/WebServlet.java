package com;

public @interface WebServlet {

	String value();

}
